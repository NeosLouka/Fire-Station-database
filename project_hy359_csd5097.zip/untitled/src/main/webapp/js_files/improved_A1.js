// Επιλογή των πεδίων φόρμας
const passwordField = document.getElementById("password");
const confirmPasswordField = document.getElementById("confirm_password");
const togglePassword = document.getElementById("togglePassword");
const toggleConfirmPassword = document.getElementById("toggleConfirmPassword");
const passwordMessage = document.getElementById("passwordMessage");
const passwordMismatchMessage = document.getElementById("passwordMismatchMessage");


// Συνάρτηση για εμφάνιση/απόκρυψη πεδίων εθελοντών
function toggleVolunteerFields() {
  const userType = document.getElementById("userType").value;
  const volunteerFields = document.getElementById("volunteerFields");
  const simpleUserFields = document.getElementById("simpleUserFields"); // Προσθήκη αν έχεις διαφορετικά πεδία για απλούς χρήστες

  if (userType === "volunteer") {
    volunteerFields.style.display = "block";
    if (simpleUserFields) simpleUserFields.style.display = "none"; // Απόκρυψη πεδίων απλού χρήστη αν υπάρχουν
  } else {
    if (volunteerFields) volunteerFields.style.display = "none"; // Απόκρυψη πεδίων εθελοντή
    if (simpleUserFields) simpleUserFields.style.display = "block"; // Εμφάνιση πεδίων απλού χρήστη αν υπάρχουν
  }
}

document.getElementById("userType").addEventListener("change", toggleVolunteerFields); // Ενεργοποίηση της toggleVolunteerFields κατά την αλλαγή του userType
