"user strict";
console.log("ajax js file")
function attemptLogin() {
    var formData = new FormData(document.getElementById('loginForm'));

    fetch('LoginServlet', {
        method: 'POST',
        body: formData
    }).then(response => response.text())
        .then(html => {
            if (html.includes('User not found')) {
                // Show prompt inside the page without reloading
                var userChoice = confirm('User not found. Do you want to register?');
                if (userChoice) {
                    window.location.href = 'register.html';
                }
            } else {
                document.getElementById('alertPlaceholder').innerHTML = html;
            }
        }).catch(error => console.error('Error:', error));
}