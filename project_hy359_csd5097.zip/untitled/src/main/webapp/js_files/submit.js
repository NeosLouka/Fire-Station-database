"use strict";
//
// // Function to create and send JSON
// document.getElementById("volunteerForm").onsubmit = async function (event) {
//   event.preventDefault(); // Prevent default form submission
//
//   // Gather form data
//   const formData = {
//     username: document.getElementById("username").value.trim(),
//     email: document.getElementById("email").value.trim(),
//     password: document.getElementById("password").value.trim(),
//     confirmPassword: document.getElementById("confirm_password").value.trim(),
//     firstname: document.getElementById("firstname").value.trim(),
//     lastname: document.getElementById("lastname").value.trim(),
//     birthdate: document.getElementById("birthdate").value,
//     gender: document.querySelector('input[name="gender"]:checked').value,
//     afm: document.getElementById("afm").value.trim(),
//     country: document.getElementById("country").value,
//     municipality: document.getElementById("municipality").value.trim(),
//     prefecture: document.getElementById("prefecture").value,
//     address: document.getElementById("address").value.trim(),
//     job: document.getElementById("job").value.trim(),
//     telephone: document.getElementById("telephone").value.trim(),
//     userType: document.getElementById("userType").value,
//     age: parseInt(document.getElementById("age").value),
//     termsAccepted: document.getElementById("terms").checked,
//   };
//
//   // Check if userType is volunteer and collect additional data
//   if (formData.userType === "volunteer") {
//     formData.volunteerType = document.getElementById("volunteerType").value;
//     formData.height = parseFloat(document.getElementById("height").value);
//     formData.weight = parseFloat(document.getElementById("weight").value);
//     formData.termsVolunteer = document.getElementById("termsMessage").checked;
//   }
//
//   // Validation: Ensure password and confirm password match
//   if (formData.password !== formData.confirmPassword) {
//     document.getElementById("responseMessage").textContent =
//       "Error: Passwords do not match.";
//     return;
//   }
//
//   // Validation: Ensure age is within the allowed range for volunteers
//   if (
//     formData.userType === "volunteer" &&
//     (formData.age < 18 || formData.age > 55)
//   ) {
//     document.getElementById("responseMessage").textContent =
//       "Error: Η ηλικία του εθελοντή πυροσβέστη πρέπει να είναι μεταξύ 18 και 55 ετών.";
//     return;
//   }
//
//   // Send JSON to the server
//   try {
//     const response = await fetch("http://localhost:8080/untitled_war_exploded/register.html", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify(formData),
//     });
//
//     if (response.ok) {
//       const result = await response.json();
//       document.getElementById("responseMessage").textContent =
//         "Submission Successful: " + result.message;
//     } else {
//       document.getElementById("responseMessage").textContent =
//         "Error: " + response.statusText;
//     }
//   } catch (error) {
//     document.getElementById("responseMessage").textContent =
//       "Error sending data to the server.";
//     console.error("Error:", error);
//   }
// };
