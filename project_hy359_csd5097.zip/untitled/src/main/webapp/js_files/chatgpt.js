async function askChatGPT(prompt) {
    const API_KEY = "YOUR_API_KEY";  // Αντικαταστήστε με το σωστό API key (μην το αφήσετε δημόσιο!)
    const API_URL = "https://api.openai.com/v1/chat/completions";

    const response = await fetch(API_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${API_KEY}`
        },
        body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [{ role: "user", content: prompt }],
            max_tokens: 100
        })
    });

    const data = await response.json();
    return data.choices[0].message.content;
}

// Παράδειγμα χρήσης:
askChatGPT("Πώς να αντιμετωπίσω μια φωτιά στο σπίτι;")
    .then(response => console.log(response))
    .catch(error => console.error("Error:", error));
