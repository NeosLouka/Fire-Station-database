package DoGetServlets;


import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

@WebServlet("/GetStatisticsServlet")
public class GetStatisticsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (Connection conn = getConnection()) {
            JSONObject stats = new JSONObject();

            // Number of occurrences by type
            stats.put("occurrencesByType", getOccurrencesByType(conn));

            // Total number of volunteers
            stats.put("totalVolunteers", getTotalCount(conn, "volunteer_user"));

            // Number of volunteers by type who are assigned to an occurrence
            stats.put("volunteerTypeCount", getVolunteerTypeCount(conn));

            response.getWriter().write(stats.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("{\"error\": \"Database error\", \"details\": \"" + e.getMessage() + "\"}");
        }
    }

    private JSONArray getOccurrencesByType(Connection conn) throws SQLException {
        String query = "SELECT name, COUNT(*) as count FROM occurrence GROUP BY name;";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        JSONArray results = new JSONArray();
        while (rs.next()) {
            JSONObject obj = new JSONObject();
            obj.put("name", rs.getString("name"));
            obj.put("count", rs.getInt("count"));
            results.put(obj);
        }
        return results;
    }

    private int getTotalCount(Connection conn, String tableName) throws SQLException {
        String query = "SELECT COUNT(*) as count FROM " + tableName;
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        rs.next();
        return rs.getInt("count");
    }

    private JSONObject getVolunteerTypeCount(Connection conn) throws SQLException {
        String query = "SELECT volunteertype, COUNT(*) as count FROM volunteer_user WHERE id IN (SELECT volunteer_id FROM Volunteer_Assignments) GROUP BY volunteertype;";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        JSONObject results = new JSONObject();
        while (rs.next()) {
            results.put(rs.getString("volunteertype"), rs.getInt("count"));
        }
        return results;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/event_management", "root", "");
    }
}
