package DoGetServlets;

import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

@WebServlet("/GetRunningMessagesServlet")
public class GetRunningMessagesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        try (Connection conn = getConnection()) {
            // Προσθήκη του φίλτρου για τα συμβάντα που έχουν κατάσταση "running"
            String sql = "SELECT o.id as event_id, o.name, m.message_content FROM occurrence o JOIN messages m ON o.id = m.event_id WHERE o.status = 'running' ORDER BY o.id, m.message_id;";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            JSONArray eventsArray = new JSONArray();
            JSONObject currentEvent = null;
            int currentEventId = -1;

            while (rs.next()) {
                int eventId = rs.getInt("event_id");
                if (eventId != currentEventId) {
                    if (currentEvent != null) {
                        eventsArray.put(currentEvent);
                    }
                    currentEvent = new JSONObject();
                    currentEvent.put("id", eventId);
                    currentEvent.put("name", rs.getString("name"));
                    currentEvent.put("messages", new JSONArray());
                    currentEventId = eventId;
                }
                JSONObject message = new JSONObject();
                message.put("content", rs.getString("message_content"));
                currentEvent.getJSONArray("messages").put(message);
            }
            if (currentEvent != null) {
                eventsArray.put(currentEvent);
            }

            response.getWriter().write(eventsArray.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("{\"error\": \"Database error\", \"details\": \"" + e.getMessage() + "\"}");
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/event_management", "root", "");
    }
}
