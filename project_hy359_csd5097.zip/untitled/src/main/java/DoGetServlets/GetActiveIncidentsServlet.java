package DoGetServlets;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet("/GetActiveIncidentsServlet")
public class GetActiveIncidentsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (Connection conn = getConnection()) {
            String sql = "SELECT id, name, description, status, danger, drivers, firemen, place_code FROM occurrence WHERE status = 'running'";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            JSONArray incidentsArray = new JSONArray();
            while (rs.next()) {
                JSONObject incident = new JSONObject();
                incident.put("id", rs.getInt("id"));
                incident.put("name", rs.getString("name"));
                incident.put("description", rs.getString("description"));
                incident.put("status", rs.getString("status"));
                incident.put("danger", rs.getString("danger"));
                incident.put("drivers", rs.getInt("drivers"));
                incident.put("firemen", rs.getInt("firemen"));
                incident.put("place_code", rs.getString("place_code"));  // Προσθήκη του place_code
                incidentsArray.put(incident);
            }

            response.getWriter().write(incidentsArray.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("{\"error\": \"Database error\", \"details\": \"" + e.getMessage() + "\"}");
        }
    }

    private Connection getConnection() throws SQLException {
        // Replace with your actual database connection setup
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/event_management", "root", "");
    }
}
