package DoGetServlets;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
@WebServlet("/GetIncidentDetailsServlet")
public class GetIncidentDetailsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        int id = Integer.parseInt(request.getParameter("id"));

        try (Connection conn = getConnection()) {
            String sql = "SELECT name, description, status, danger, drivers, firemen FROM occurrence WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String jsonResult = String.format(
                        "{\"name\": \"%s\", \"description\": \"%s\", \"status\": \"%s\", \"danger\": \"%s\", \"drivers\": %d, \"firemen\": %d}",
                        rs.getString("name"), rs.getString("description"), rs.getString("status"), rs.getString("danger"),
                        rs.getInt("drivers"), rs.getInt("firemen")
                );
                response.getWriter().write(jsonResult);
            } else {
                response.getWriter().write("{\"error\": \"Incident not found.\"}");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("{\"error\": \"Database error\", \"details\": \"" + e.getMessage() + "\"}");
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/event_management", "root", "");
    }
}
