package DoGetServlets;

import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/GetVolunteerIncidentsServlet")
public class GetVolunteerIncidentsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"error\": \"User not logged in.\"}");
            return;
        }

        String volunteerType = (String) session.getAttribute("volunteerType");
        if (volunteerType == null) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"Volunteer type not found in session.\"}");
            return;
        }

        try (Connection conn = getConnection()) {
            String sql = "SELECT id, name, description FROM occurrence WHERE status = 'running' AND " +
                    (volunteerType.equals("driver") ? "drivers > 0" : "firemen > 0");

            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            JSONArray incidents = new JSONArray();
            while (rs.next()) {
                JSONObject incident = new JSONObject();
                incident.put("id", rs.getInt("id"));
                incident.put("name", rs.getString("name"));
                incident.put("description", rs.getString("description"));
                incidents.put(incident);
            }

            response.getWriter().write(incidents.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("{\"error\": \"Database error\", \"details\": \"" + e.getMessage() + "\"}");
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/event_management", "root", "");
    }
}
