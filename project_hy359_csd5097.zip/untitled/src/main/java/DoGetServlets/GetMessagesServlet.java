package DoGetServlets;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import org.json.JSONArray;
import org.json.JSONObject;


@WebServlet("/GetMessagesServlet")
public class GetMessagesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT message_id, message_content FROM messages ORDER BY message_id")) {
            ResultSet rs = pstmt.executeQuery();

            JSONArray messagesArray = new JSONArray();
            while (rs.next()) {
                JSONObject message = new JSONObject();
                message.put("message_id", rs.getInt("message_id"));
                message.put("message_content", rs.getString("message_content"));
                messagesArray.put(message);
            }

            response.getWriter().write(messagesArray.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"Database error\", \"details\": \"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"Internal server error\", \"details\": \"" + e.getMessage() + "\"}");
        }
    }
    private Connection getConnection() throws SQLException {
        // Replace with your actual database connection setup
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/event_management", "root", "");
    }
}