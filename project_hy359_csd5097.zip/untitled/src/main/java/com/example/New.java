package com.example;

import java.sql.*;
import java.time.LocalDate;
import java.util.List;


//
public class New {
//

    public static void createUser(String username, String email, String password, String firstName, String lastName,
                                  String birthdate, String gender, String afm, String country, String municipality,
                                  String prefecture, String job, String telephone, String userType, int age, String terms) {
        // SQL εντολή με σωστό αριθμό placeholders
        String insertUserSQL = "INSERT INTO users (username, email, password, firstname, lastname, birthdate, gender, afm, country, municipality, prefecture, job, telephone, usertype, age, terms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertUserSQL)) {

            // Ορισμός παραμέτρων στη SQL
            pstmt.setString(1, username);
            pstmt.setString(2, email);
            pstmt.setString(3, password);
            pstmt.setString(4, firstName);
            pstmt.setString(5, lastName);
            pstmt.setString(6, birthdate);
            pstmt.setString(7, gender);
            pstmt.setString(8, afm);
            pstmt.setString(9, country);
            pstmt.setString(10, municipality);
            pstmt.setString(11, prefecture);
            pstmt.setString(12, job);
            pstmt.setString(13, telephone);
            pstmt.setString(14, userType);
            pstmt.setInt(15, age);
            pstmt.setString(16, terms);

            // Εκτέλεση εντολής
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("User added successfully!");
            } else {
                System.out.println("Failed to add user.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while adding user: " + e.getMessage());
        }
    }


    public static void createOccurrenceWithMessages(String name, String startDate, String endDate,
                                                    String startTime, String endTime, String danger, String description,
                                                    int firemen, int drivers, String status, String placeCode,
                                                    List<String> messages) {
        // SQL statement for inserting a new occurrence
        String insertOccurrenceSQL = "INSERT INTO occurrence (name, start_date, end_date, start_time, end_time, " +
                "danger, description, firemen, drivers, status, place_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertOccurrenceSQL, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, name);
            pstmt.setString(2, startDate);
            pstmt.setString(3, endDate);
            pstmt.setString(4, startTime);
            pstmt.setString(5, endTime);
            pstmt.setString(6, danger);
            pstmt.setString(7, description);
            pstmt.setInt(8, firemen);
            pstmt.setInt(9, drivers);
            pstmt.setString(10, status);
            pstmt.setString(11, placeCode);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating occurrence failed, no rows affected.");
            }

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    long occurrenceId = generatedKeys.getLong(1);
                    // Call method to insert messages linked with this occurrence
                    insertMessages(conn, occurrenceId, messages);
                } else {
                    throw new SQLException("Creating occurrence failed, no ID obtained.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while adding occurrence: " + e.getMessage());
        }
    }

    private static void insertMessages(Connection conn, long occurrenceId, List<String> messages) throws SQLException {
        String insertMessageSQL = "INSERT INTO messages (event_id, message_content) VALUES (?, ?);";
        try (PreparedStatement pstmt = conn.prepareStatement(insertMessageSQL)) {
            for (String message : messages) {
                pstmt.setLong(1, occurrenceId);
                pstmt.setString(2, message);
                pstmt.executeUpdate();
            }
        }
    }

    public static void addMessagesToOccurrence(int occurrenceId, List<String> messages) {
        String insertMessageSQL = "INSERT INTO messages (event_id, message_content) VALUES (?, ?);";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertMessageSQL)) {
            for (String message : messages) {
                System.out.println("Inserting message: " + message);  // Εκτύπωση του μηνύματος πριν την εισαγωγή
                pstmt.setLong(1, occurrenceId);
                pstmt.setString(2, message);
                int result = pstmt.executeUpdate();
                System.out.println("Result of insert: " + result);  // Εκτύπωση του αποτελέσματος της εισαγωγής
            }

            System.out.println("Messages added successfully to occurrence ID: " + occurrenceId);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while adding messages to occurrence: " + e.getMessage());
        }
    }

    public static void createVolunteer(String username, String email, String password, String firstName,
                                       String lastName, String birthdate, String gender, String afm, String country,
                                       String municipality, String prefecture, String job, String telephone, int age,
                                       String terms, String usertype, String volunteertype, float height, int weight,
                                       String termsMessage , int availability) {
        String insertVolunteerSQL = "INSERT INTO volunteer_user (username, email, password, firstname, lastname, birthdate, gender, afm, country, municipality, prefecture, job, telephone, age, terms, usertype, volunteertype, height, weight, termsMessage , availability) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?);";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertVolunteerSQL)) {

            pstmt.setString(1, username);
            pstmt.setString(2, email);
            pstmt.setString(3, password);
            pstmt.setString(4, firstName);
            pstmt.setString(5, lastName);
            pstmt.setString(6, birthdate);
            pstmt.setString(7, gender);
            pstmt.setString(8, afm);
            pstmt.setString(9, country);
            pstmt.setString(10, municipality);
            pstmt.setString(11, prefecture);
            pstmt.setString(12, job);
            pstmt.setString(13, telephone);
            pstmt.setInt(14, age);
            pstmt.setString(15, terms);
            pstmt.setString(16, usertype);
            pstmt.setString(17, volunteertype);
            pstmt.setFloat(18, height);
            pstmt.setInt(19, weight);
            pstmt.setString(20, termsMessage);
            pstmt.setInt(21, availability);


            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Volunteer added successfully!");
            } else {
                System.out.println("Failed to add volunteer.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while adding volunteer: " + e.getMessage());
        }
    }

    public static void assignAvailableVolunteersToOccurrence(int occurrenceId) {
        try (Connection conn = DataBaseConnection.getConnection()) {
            // Εύρεση αριθμών firemen και drivers που απαιτούνται για το συμβάν
            PreparedStatement checkOccurrenceStmt = conn.prepareStatement("SELECT firemen, drivers FROM occurrence WHERE id = ?;");
            checkOccurrenceStmt.setInt(1, occurrenceId);
            ResultSet occurrenceResult = checkOccurrenceStmt.executeQuery();

            if (!occurrenceResult.next()) {
                System.out.println("Occurrence not found");
                return; // Διακόπτει την εκτέλεση αν δεν βρεθεί το συμβάν
            }

            int requiredFiremen = occurrenceResult.getInt("firemen");
            int requiredDrivers = occurrenceResult.getInt("drivers");

            // Αναζήτηση διαθέσιμων εθελοντών
            String findAvailableVolunteersSQL = "SELECT id, volunteertype FROM volunteer_user WHERE availability = 1;";
            Statement stmt = conn.createStatement();
            ResultSet availableVolunteers = stmt.executeQuery(findAvailableVolunteersSQL);

            String assignVolunteerSQL = "INSERT INTO Volunteer_Assignments (volunteer_id, occurrence_id) VALUES (?, ?);";
            PreparedStatement assignStmt = conn.prepareStatement(assignVolunteerSQL);

            String updateAvailabilitySQL = "UPDATE volunteer_user SET availability = 0 WHERE id = ?;";
            PreparedStatement updateAvailabilityStmt = conn.prepareStatement(updateAvailabilitySQL);

            // Ενημέρωση αριθμών εθελοντών για το συμβάν
            String updateOccurrenceSQL = "UPDATE occurrence SET firemen = GREATEST(0, firemen - ?), drivers = GREATEST(0, drivers - ?), status = 'running' WHERE id = ?;";
            PreparedStatement updateOccurrenceStmt = conn.prepareStatement(updateOccurrenceSQL);
            int firemenToUpdate = 0;
            int driversToUpdate = 0;

            while (availableVolunteers.next()) {
                int volunteerId = availableVolunteers.getInt("id");
                String volunteerType = availableVolunteers.getString("volunteertype");

                if (("simple".equals(volunteerType) && requiredFiremen > 0) || ("driver".equals(volunteerType) && requiredDrivers > 0)) {
                    // Ανάθεση στο συμβάν
                    assignStmt.setInt(1, volunteerId);
                    assignStmt.setInt(2, occurrenceId);
                    assignStmt.executeUpdate();

                    // Ενημέρωση διαθεσιμότητας
                    updateAvailabilityStmt.setInt(1, volunteerId);
                    updateAvailabilityStmt.executeUpdate();

                    // Αύξηση των αντίστοιχων μετρητών
                    if ("simple".equals(volunteerType)) {
                        firemenToUpdate++;
                        requiredFiremen--;
                    } else if ("driver".equals(volunteerType)) {
                        driversToUpdate++;
                        requiredDrivers--;
                    }
                }
            }

            // Ενημέρωση συμβάντος
            updateOccurrenceStmt.setInt(1, firemenToUpdate);
            updateOccurrenceStmt.setInt(2, driversToUpdate);
            updateOccurrenceStmt.setInt(3, occurrenceId);
            updateOccurrenceStmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }




//    public static void NewCustomer(String loginname, String password, String name, String lastname, String email,String phonenumber,
//                                   String creditCardNumber, String creditCardCVV, String creditCardDate,int balance) {
//
//
//        String insertCustomerSQL = "INSERT INTO customers (loginname, password, name, lastname, email,phonenumber ,C_C_Num, C_C_CVV, C_C_Date,C_C_Balance) "
//                + "VALUES (?, ?,?, ?, ?, ?, ?, ?, ?, ?);";
//
//        try (Connection conn =DataBaseConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(insertCustomerSQL)) {
//
//            // Ορισμός παραμέτρων στη SQL
//            pstmt.setString(1, loginname);
//            pstmt.setString(2, password);
//            pstmt.setString(3, name);
//            pstmt.setString(4, lastname); // Δέχεται null εάν δεν δοθεί
//            pstmt.setString(5, email);
//            pstmt.setString(6, phonenumber);
//            pstmt.setString(7, creditCardNumber); // Δέχεται null εάν δεν δοθεί
//            pstmt.setString(8, creditCardCVV);    // Δέχεται null εάν δεν δοθεί
//            pstmt.setString(9, creditCardDate);   // Δέχεται null εάν δεν δοθεί
//            pstmt.setInt(10, balance);
//
//            // Εκτέλεση εντολής
//            int rowsInserted = pstmt.executeUpdate();
//            if (rowsInserted > 0) {
//                System.out.println("Customer added successfully!");
//            } else {
//                System.out.println("Failed to add customer.");
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//            System.out.println("Error while adding customer: " + e.getMessage());
//        }
//    }
//
//
//    public static void NewEvent(String name,String date,String time,String event_type,int capacity ) {
//
//        String insertEventSQL = "INSERT INTO events (name,date,time,event_type,capacity) "
//                + "VALUES (?, ?, ?, ?, ?);";
//
//        try (Connection conn = DataBaseConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(insertEventSQL)) {
//
//            pstmt.setString(1, name);
//            pstmt.setString(2, date);
//            pstmt.setString(3, time);
//            pstmt.setString(4, event_type);
//            pstmt.setInt(5, capacity);
//
//            // Εκτέλεση εντολής
//            int rowsInserted = pstmt.executeUpdate();
//            if (rowsInserted > 0) {
//                System.out.println("Event added successfully!");
//            } else {
//                System.out.println("Failed to add event.");
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//            System.out.println("Error while adding event: " + e.getMessage());
//        }
//    }
//
//
//    public static void NewTicket(int event_id ,String seat_type,float price,int availability ) {
//
//        String insertTicketSQL = "INSERT INTO tickets(event_id,seat_type,price,availability) "
//                + "VALUES (?, ?, ?, ?);";
//
//        try (Connection conn = DataBaseConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(insertTicketSQL)) {
//
//            pstmt.setInt(1, event_id);
//            pstmt.setString(2, seat_type);
//            pstmt.setFloat(3, price);
//            pstmt.setInt(4, availability);
//
//            // Εκτέλεση εντολής
//            int rowsInserted = pstmt.executeUpdate();
//            if (rowsInserted > 0) {
//                System.out.println("Ticket added successfully!");
//            } else {
//                System.out.println("Failed to add ticket.");
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//            System.out.println("Error while adding ticket: " + e.getMessage());
//        }
//    }
//
//
//    public static void NewBooking(int customer_id, int event_id, int ticket_amount, String seat_type) {
//        // Ερώτημα για να βρεις την τιμή του εισιτηρίου από τον τύπο θέσης
//        String getTicketPriceSQL = "SELECT price FROM tickets WHERE seat_type = ?";
//
//        // Ερώτημα για να κάνεις την εισαγωγή στην βάση
//        String insertBookingSQL = "INSERT INTO bookings(customer_id, event_id, ticket_amount, seat_type, date, payment_amount) "
//                + "VALUES (?, ?, ?, ?, ?, ?);";
//
//        try (Connection conn = DataBaseConnection.getConnection()) {
//            // Βήμα 1: Ανάκτηση της τιμής του εισιτηρίου για το seat_type
//            float ticketPrice = 0;
//            try (PreparedStatement getPriceStmt = conn.prepareStatement(getTicketPriceSQL)) {
//                getPriceStmt.setString(1, seat_type);
//                ResultSet rs = getPriceStmt.executeQuery();
//
//                if (rs.next()) {
//                    ticketPrice = rs.getFloat("price");  // Παίρνουμε την τιμή του εισιτηρίου
//                } else {
//                    System.out.println("Seat type not found.");
//                    return;  // Εάν δεν βρεθεί ο τύπος θέσης, σταματάμε την εκτέλεση
//                }
//            }
//
//            // Βήμα 2: Υπολογισμός του payment_amount
//            float paymentAmount = ticketPrice * ticket_amount;
//
//            // Βήμα 3: Εισαγωγή της κράτησης στη βάση δεδομένων μαζί με το υπολογισμένο payment_amount
//            try (PreparedStatement pstmt = conn.prepareStatement(insertBookingSQL)) {
//                pstmt.setInt(1, customer_id);
//                pstmt.setInt(2, event_id);
//                pstmt.setInt(3, ticket_amount);
//                pstmt.setString(4, seat_type);
//                pstmt.setString(5, Action.RandomDateGenerator());
//                pstmt.setFloat(6, paymentAmount);  // Βάζουμε το υπολογισμένο payment_amount
//
//                // Εκτέλεση της εντολής
//                int rowsInserted = pstmt.executeUpdate();
//                if (rowsInserted > 0) {
//                    System.out.println("Booking added successfully!");
//                } else {
//                    System.out.println("Failed to add booking.");
//                }
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//            System.out.println("Error while adding booking: " + e.getMessage());
//        }
//    }
//
//    public static void NewAdmin(String name, String password) {
//
//
//        String insertCustomerSQL = "INSERT INTO admins (name ,password) "
//                + "VALUES (?,?);";
//
//        try (Connection conn =DataBaseConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(insertCustomerSQL)) {
//
//            // Ορισμός παραμέτρων στη SQL
//            pstmt.setString(1, name);
//            pstmt.setString(2, password);
//
//
//            // Εκτέλεση εντολής
//            int rowsInserted = pstmt.executeUpdate();
//            if (rowsInserted > 0) {
//                System.out.println("Customer added successfully!");
//            } else {
//                System.out.println("Failed to add customer.");
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//            System.out.println("Error while adding customer: " + e.getMessage());
//        }
//    }
//
//    public static void NewCustomer(String loginname, String password, String name) {
//        NewCustomer(loginname, password, name, null,null, null, null, null, null,5000);
//    }
//    public static void NewEvent(String name,String date) {
//        NewEvent(name, date, null, null, -1);
//    }
//    public static void NewTicket(int event_id,String seat_type) {
//        NewTicket(event_id, seat_type, -1, -1);
//    }
//    public static void NewBooking(int customer_id,int event_id) {
//        NewBooking(customer_id, event_id, -1,null);
//    }
}
