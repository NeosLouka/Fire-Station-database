package com.example.DoPostServlets;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (Connection conn = getConnection()) {
            // Check in users table
            if (checkUser(conn, "users", username, password)) {
                String userType = getUserType(conn, "users", username);
                setCookies(response, username, userType, null);

                if ("admin".equals(userType)) {
                    response.sendRedirect("admin_main.html");
                } else {
                    response.sendRedirect("user_main.html");
                }
            }
            // Check in volunteer_user table
            else if (checkUser(conn, "volunteer_user", username, password)) {
                String userType = "volunteer";
                String volunteerType = getVolunteerType(conn, username);

                setCookies(response, username, userType, volunteerType);

                response.sendRedirect("volunteer_user_main.html");
            } else {
                request.setAttribute("errorMessage", "Invalid username or password");
                request.getRequestDispatcher("/login.html").forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        }
    }

    private boolean checkUser(Connection conn, String tableName, String username, String password) throws SQLException {
        String query = "SELECT COUNT(*) FROM " + tableName + " WHERE username = ? AND password = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        }
    }

    private String getUserType(Connection conn, String tableName, String username) throws SQLException {
        String query = "SELECT usertype FROM " + tableName + " WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("usertype");
            }
            return null;
        }
    }

    private String getVolunteerType(Connection conn, String username) throws SQLException {
        String query = "SELECT volunteertype FROM volunteer_user WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("volunteertype");
            }
            return null;
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/event_management", "root", "");
    }

    private void setCookies(HttpServletResponse response, String username, String userType, String volunteerType) {
        Cookie usernameCookie = new Cookie("username", username);
        usernameCookie.setMaxAge(86400); // 24 hours
        response.addCookie(usernameCookie);

        Cookie userTypeCookie = new Cookie("usertype", userType);
        userTypeCookie.setMaxAge(86400); // 24 hours
        response.addCookie(userTypeCookie);

        if (volunteerType != null) {
            Cookie volunteerTypeCookie = new Cookie("volunteertype", volunteerType);
            volunteerTypeCookie.setMaxAge(86400); // 24 hours
            response.addCookie(volunteerTypeCookie);
        }
    }
}
