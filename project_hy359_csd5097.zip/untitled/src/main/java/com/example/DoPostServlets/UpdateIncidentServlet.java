package com.example.DoPostServlets;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
@WebServlet("/UpdateIncidentServlet")
public class UpdateIncidentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String incidentName = request.getParameter("incidentName");
        String description = request.getParameter("description");
        String status = request.getParameter("status");
        int drivers = Integer.parseInt(request.getParameter("drivers"));
        int firemen = Integer.parseInt(request.getParameter("firemen"));
        int id = Integer.parseInt(request.getParameter("id"));

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
        Date now = new Date();
        String currentDate = dateFormat.format(now);
        String currentTime = timeFormat.format(now);

        Connection conn = null;
        try {
            conn = getConnection();
            conn.setAutoCommit(false);  // Start transaction

            StringBuilder sql = new StringBuilder("UPDATE occurrence SET name = ?, description = ?, status = ?, drivers = IF(? = 'finished', 0, ?), firemen = IF(? = 'finished', 0, ?)");

            if ("running".equals(status)) {
                sql.append(", start_date = '").append(currentDate).append("', start_time = '").append(currentTime).append("'");
            } else if ("finished".equals(status)) {
                sql.append(", end_date = '").append(currentDate).append("', end_time = '").append(currentTime).append("'");
            }

            sql.append(" WHERE id = ?");

            PreparedStatement stmt = conn.prepareStatement(sql.toString());
            stmt.setString(1, incidentName);
            stmt.setString(2, description);
            stmt.setString(3, status);
            stmt.setString(4, status);  // Condition for resetting drivers
            stmt.setInt(5, drivers);
            stmt.setString(6, status);  // Condition for resetting firemen
            stmt.setInt(7, firemen);
            stmt.setInt(8, id);

            stmt.executeUpdate();

            // If the incident is marked as finished, update volunteer availability
            if ("finished".equals(status)) {
                String volunteerResetSql = "UPDATE volunteer_user SET availability = 1 WHERE id IN (SELECT volunteer_id FROM Volunteer_Assignments WHERE occurrence_id = ?)";
                PreparedStatement volunteerStmt = conn.prepareStatement(volunteerResetSql);
                volunteerStmt.setInt(1, id);
                volunteerStmt.executeUpdate();
            }

            conn.commit();  // Commit transaction
            response.getWriter().write("{\"success\": true}");
        } catch (SQLException e) {
            e.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback on error
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            response.getWriter().write("{\"error\": \"Database error\", \"details\": \"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("{\"error\": \"Internal server error\", \"details\": \"" + e.getMessage() + "\"}");
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);  // Reset auto-commit
                    conn.close();  // Close connection
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private Connection getConnection() throws SQLException {
        // Setup your database connection here
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/event_management", "root", "");
    }
}
