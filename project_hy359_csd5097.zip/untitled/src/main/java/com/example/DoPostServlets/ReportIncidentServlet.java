package com.example.DoPostServlets;

import com.example.New;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.Arrays;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/ReportIncidentServlet")
public class ReportIncidentServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String placeCode = request.getParameter("placeCode");

        // Automatically set the date and time of the report
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
        Date now = new Date();
        String currentDate = dateFormat.format(now);
        String currentTime = timeFormat.format(now);

        // Create the occurrence with messages
        try {
            New.createOccurrenceWithMessages(name, currentDate, currentDate, currentTime, currentTime,
                    "unknown", description, 0, 0, "submitted", placeCode,
                    Arrays.asList("Initial report completed."));
            response.sendRedirect("user_main.html");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("incident_report_error.html");
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/event_management", "root", "");
    }
}
