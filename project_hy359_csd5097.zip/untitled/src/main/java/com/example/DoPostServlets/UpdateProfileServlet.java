package com.example.DoPostServlets;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String firstName = request.getParameter("firstname");
        String lastName = request.getParameter("lastname");
        String birthdate = request.getParameter("birthdate");
        String gender = request.getParameter("gender");
        String job = request.getParameter("job");
        String telephone = request.getParameter("telephone");

        String username = null;

        // Retrieve username from cookies
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("username".equals(cookie.getName())) {
                    username = cookie.getValue();
                    break;
                }
            }
        }

        if (username == null) {
            response.sendRedirect("login.html"); // No username cookie found, redirect to login
            return;
        }

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE users SET firstname = ?, lastname = ?, birthdate = ?, gender = ?, job = ?, telephone = ? WHERE username = ?")) {
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, birthdate);
            stmt.setString(4, gender);
            stmt.setString(5, job);
            stmt.setString(6, telephone);
            stmt.setString(7, username);

            int result = stmt.executeUpdate();
            if (result > 0) {
                response.sendRedirect("user_main.html"); // Redirect on successful update
            } else {
                response.sendRedirect("login.html"); // Redirect if no update occurred
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error during profile update");
        }
    }

    private Connection getConnection() throws SQLException {
        // Replace with your actual database connection setup
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/event_management", "root", "");
    }
}
