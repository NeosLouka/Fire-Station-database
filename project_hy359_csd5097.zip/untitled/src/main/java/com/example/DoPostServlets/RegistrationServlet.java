package com.example.DoPostServlets;

import com.example.New;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Λήψη των δεδομένων από τη φόρμα
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String firstName = request.getParameter("firstname");
        String lastName = request.getParameter("lastname");
        String birthdate = request.getParameter("birthdate");
        String gender = request.getParameter("gender");
        String afm = request.getParameter("afm");
        String country = request.getParameter("country");
        String municipality = request.getParameter("municipality");
        String prefecture = request.getParameter("prefecture");
        String job = request.getParameter("job");
        String telephone = request.getParameter("telephone");
        String userType = request.getParameter("userType");
        int age = Integer.parseInt(request.getParameter("age"));
        String terms = request.getParameter("terms");
        String volunteertype = request.getParameter("volunteerType");
        float height = Float.parseFloat(request.getParameter("height"));
        int weight = Integer.parseInt(request.getParameter("weight"));


        try {
            if(userType.equals("volunteer")){
                New.createVolunteer( username,email,password,firstName,lastName,birthdate,gender,afm,country,municipality,prefecture,job,telephone,age,terms,userType,volunteertype,height,weight,"Agreed terms and conditions " , 1);
            }else {
                // Κλήση της μεθόδου για δημιουργία νέου χρήστη
                New.createUser(username, email, password, firstName, lastName, birthdate, gender, afm, country, municipality, prefecture, job, telephone, userType, age, terms);
            }
            response.sendRedirect("login_screen.html"); // Ανακατεύθυνση σε σελίδα επιτυχίας
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.html"); // Ανακατεύθυνση σε σελίδα σφάλματος
        }
    }

}
