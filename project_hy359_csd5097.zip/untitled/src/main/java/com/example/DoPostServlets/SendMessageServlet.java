package com.example.DoPostServlets;

import com.example.New;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Arrays;

@WebServlet("/SendMessageServlet")
public class SendMessageServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int occurrenceId = Integer.parseInt(request.getParameter("occurrenceId"));
        String messageContent = request.getParameter("messageContent");

        // Assuming 'addMessagesToOccurrence' is static and can handle a single string message as a list
        New.addMessagesToOccurrence(occurrenceId, Arrays.asList(messageContent));

        response.sendRedirect("messages.html");
    }
}
