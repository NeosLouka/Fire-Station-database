package com.example;

import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MyServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        try (Connection conn = DataBaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            // Drop and recreate the database to start fresh
            stmt.executeUpdate("DROP DATABASE IF EXISTS event_management;");
            stmt.executeUpdate("CREATE DATABASE event_management;");
            stmt.executeUpdate("USE event_management;");

            // Create occurrence table
            String createOccurrenceTableSQL = "CREATE TABLE IF NOT EXISTS occurrence (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "name VARCHAR(20) NOT NULL, " +
                    "start_date VARCHAR(10) NOT NULL, " +
                    "end_date VARCHAR(10) NOT NULL, " +
                    "start_time VARCHAR(10), " +
                    "end_time VARCHAR(10), " +
                    "danger VARCHAR(10), " +
                    "description VARCHAR(100), " +
                    "firemen INT, " +
                    "drivers INT, " +
                    "messages VARCHAR(100), " +
                    "status VARCHAR(10), " +
                    "place_code VARCHAR(10)" +
                    ");";
            stmt.executeUpdate(createOccurrenceTableSQL);

            // Create the users table
            String createUserTableSQL = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "username VARCHAR(255) NOT NULL, " +
                    "email VARCHAR(255) NOT NULL, " +
                    "password VARCHAR(255) NOT NULL, " +
                    "firstname VARCHAR(255) NOT NULL, " +
                    "lastname VARCHAR(255) NOT NULL, " +
                    "birthdate VARCHAR(10), " +
                    "gender VARCHAR(10), " +
                    "afm VARCHAR(16), " +
                    "country VARCHAR(255), " +
                    "municipality VARCHAR(255), " +
                    "prefecture VARCHAR(255), " +
                    "job VARCHAR(255), " +
                    "telephone VARCHAR(10), " +
                    "usertype VARCHAR(255), " +
                    "age INT, " +
                    "terms VARCHAR(255) " +
                    ");";
            stmt.executeUpdate(createUserTableSQL);

            // Create messages table with correct foreign key reference
            String createMessagesTableSQL = "CREATE TABLE IF NOT EXISTS messages (" +
                    "message_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "event_id INT, " +
                    "message_content VARCHAR(100), " +
                    "FOREIGN KEY (event_id) REFERENCES occurrence(id) " +  // Make sure this references the correct table name
                    ");";
            stmt.executeUpdate(createMessagesTableSQL);

            // Create volunteer user table without syntax error
            String createVolunteerUserTableSQL = "CREATE TABLE IF NOT EXISTS volunteer_user (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "username VARCHAR(255) NOT NULL, " +
                    "email VARCHAR(255) NOT NULL, " +
                    "password VARCHAR(255) NOT NULL, " +
                    "firstname VARCHAR(255) NOT NULL, " +
                    "lastname VARCHAR(255) NOT NULL, " +
                    "birthdate VARCHAR(10) NOT NULL, " +
                    "gender VARCHAR(10) NOT NULL, " +
                    "afm VARCHAR(16) NOT NULL, " +
                    "country VARCHAR(255) NOT NULL, " +
                    "municipality VARCHAR(255) NOT NULL, " +
                    "prefecture VARCHAR(255) NOT NULL, " +
                    "job VARCHAR(255) NOT NULL, " +
                    "telephone VARCHAR(10) NOT NULL, " +
                    "age INT, " +
                    "terms VARCHAR(255) NOT NULL, " +
                    "usertype VARCHAR(255) NOT NULL, " +
                    "volunteertype VARCHAR(255) NOT NULL, " +
                    "height FLOAT, " +
                    "weight INT, " +
                    "termsMessage VARCHAR(255) NOT NULL," + // Removed the trailing comma here
                    "availability INT " +
                    ");";
            stmt.executeUpdate(createVolunteerUserTableSQL);

            String createVolunteerAssignmentsTableSQL = "CREATE TABLE IF NOT EXISTS Volunteer_Assignments (" +
                    "volunteer_id INT, " +
                    "occurrence_id INT, " +
                    "FOREIGN KEY (volunteer_id) REFERENCES volunteer_user(id), " +
                    "FOREIGN KEY (occurrence_id) REFERENCES occurrence(id), " +
                    "PRIMARY KEY (volunteer_id, occurrence_id)" +
                    ");";
            stmt.executeUpdate(createVolunteerAssignmentsTableSQL);


        } catch (SQLException e) {
            e.printStackTrace();
        }

        New.createUser("admin", "nlouka272@gmail.com", "admin", "NEOFYTOS", "LOUKA",
                "1985-04-12", "male", "123456789", "Greece", "Athens", "Attica",
                "Engineer", "6912345678", "admin", 35, "accept");

        for (int i = 0; i < 10; i++) {
            String username = "neos" + i;
            String email = username + "@example.com";
            String password = String.valueOf(i);
            String firstName = "neos" + i;
            String lastName = "neos";

            New.createUser(username, email, password, firstName, lastName,
                    "1985-04-12", "male", "123456789", "Greece", "Athens", "Attica",
                    "Engineer", "6912345678", "simple", 35, "accept");
        }


        String[] eventNames = {"Minor Fire", "Major Accident", "Routine Safety Check", "Environmental Alert", "Electrical Hazard", "Medical Emergency"};
        String[] statuses = {"submitted", "running", "finished", "fake"};

        Random rand = new Random();
        for (int i = 0; i < 10; i++) {
            String eventName = eventNames[rand.nextInt(eventNames.length)];
            String status = statuses[rand.nextInt(statuses.length)];

            String startDate = String.format("2025-02-%02d", rand.nextInt(10) + 6);
            String endDate = startDate;  // Same day event
            String startTime = String.format("%02d:00", rand.nextInt(11) + 8);
            String endTime = String.format("%02d:00", rand.nextInt(3) + Integer.parseInt(startTime.substring(0, 2)) + 1);
            String severity = new String[]{"Low", "Moderate", "High", "Critical"}[rand.nextInt(4)];
            String description = eventName + " scenario with " + severity + " impact.";
            int firemenNeeded = rand.nextInt(11);
            int driversNeeded = rand.nextInt(6);

            // Create an occurrence with messages
            New.createOccurrenceWithMessages(
                    eventName, startDate, endDate, startTime, endTime, severity, description,
                    firemenNeeded, driversNeeded, status, "Code" + (1000 + i),
                    Arrays.asList("Initial report completed.", "Update: Units responding.")
            );
        }
//        // Example 1: Create an occurrence for a minor incident with two messages
//        New.createOccurrenceWithMessages("Minor Fire", "2025-01-28", "2025-01-28",
//                "10:00", "11:00", "Low", "Small brush fire near the park.",
//                2, 1, "submitted", "Code123",
//                Arrays.asList("First responder dispatched.", "Fire under control."));
//
//        // Example 2: Create an occurrence for a major incident with multiple messages
//        New.createOccurrenceWithMessages("Major Accident", "2025-01-29", "2025-01-29",
//                "15:30", "18:30", "High", "Multi-car pileup on Highway 10.",
//                10, 5, "running", "Code456",
//                Arrays.asList("Emergency services on scene.", "Traffic rerouted.", "Casualties reported."));
//
//        // Example 3: Create a routine check occurrence
//        New.createOccurrenceWithMessages("Routine Safety Check", "2025-02-01", "2025-02-01",
//                "09:00", "10:00", "None", "Monthly safety inspection of facilities.",
//                3, 0, "finished", "Code789",
//                Arrays.asList("Inspection started.", "No issues found."));
//
//        // Example 4: Create an occurrence for environmental monitoring
//        New.createOccurrenceWithMessages("Environmental Alert", "2025-02-05", "2025-02-05",
//                "12:00", "14:00", "Moderate", "High pollution levels detected.",
//                0, 0, "fake", "Code321",
//                Arrays.asList("Air quality sensors activated.", "Public advised to minimize outdoor activities."));

        List<String> messages = Arrays.asList("New update on situation", "Second update: More details available", "Third update: Issue resolved");
        int occurrenceId = 1;  // Το ID του συμβάντος στο οποίο θέλεις να προσθέσεις τα μηνύματα
        New.addMessagesToOccurrence(occurrenceId, messages);

        String[] firstNames = {"John", "Jane", "Michael", "Sarah", "Alex", "Lisa"};
        String[] lastNames = {"Doe", "Smith", "Johnson", "Lee", "Brown", "Davis"};
        String[] roles = {"simple", "driver"};
        String[] cities = {"Heraklion", "Chania", "Rethymno", "Agios Nikolaos"};
        String[] prefectures = {"Crete", "Crete", "Crete", "Crete"};

        for (int i = 0; i < 30; i++) {
            String firstName = firstNames[i % firstNames.length];
            String lastName = lastNames[i % lastNames.length];
            String role = roles[i % roles.length];
            String email = "neos" + i + "@example.com";
            String username = "voluntearneos" + i;
            String userType = "volunteer";
            String city = cities[i % cities.length];
            String prefecture = prefectures[i % prefectures.length];
            String password = "securePass" + i + "!";
            String phone = "69" + (10000000 + i);
            float height = 1.50f + (i % 50) * 0.01f;
            int weight = 50 + (i % 31);

            New.createVolunteer(username, email, password, firstName, lastName, "1985-08-15", "male", "123456789",
                    "Greece", city, prefecture, role, phone, 35, "Accept", userType, role, height, weight,
                    "I agree to the terms and conditions.", 1);
        }


        New.assignAvailableVolunteersToOccurrence(1);
        New.assignAvailableVolunteersToOccurrence(2);
    }

}
